import App from '../components/App';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Home() {
  return <App />;
}
