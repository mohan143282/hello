**Super Over League Cover Page**
Super Over League Cover Page is a simple web application that displays a cover page for a fictional cricket league called "Super Over League."
Just simple cover page created with React.js.

**Usage**
Simply open the index.html file in your web browser to view the cover page for Super Over League.
